// ================================================================
// «Ближе» — backend для Telegram Mini App
// Хранит комнаты в памяти, отдаёт статику, дергает Anthropic API
// для мини-сессии психолога.
// ================================================================
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json({ limit: '1mb' }));

const PORT = process.env.PORT || 3000;
const GROQ_API_KEY = process.env.GROQ_API_KEY || '';
const GROQ_MODEL = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';

// ---------------------------------------------------------------
// Хранилище комнат (в памяти процесса).
// Для прод-нагрузки замените на Redis/БД — тут этого достаточно
// для семейной игры на двоих.
// ---------------------------------------------------------------
const rooms = new Map();
const ROOM_TTL_MS = 1000 * 60 * 60 * 12; // комнаты старше 12 часов чистим

function cleanupRooms() {
  const now = Date.now();
  for (const [code, room] of rooms) {
    if (now - room.updatedAt > ROOM_TTL_MS) rooms.delete(code);
  }
}
setInterval(cleanupRooms, 1000 * 60 * 30);

function genCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({ length: 4 }, () => chars[crypto.randomInt(chars.length)]).join('');
  } while (rooms.has(code));
  return code;
}

function touch(room) {
  room.updatedAt = Date.now();
}

function publicRoom(room) {
  // отдаём клиенту всё, что нужно для рендера
  return {
    code: room.code,
    A: room.A,
    B: room.B,
    started: room.started,
    currentIndex: room.currentIndex,
    answers: room.answers,
    secretQ: room.secretQ,
    sessionReport: room.sessionReport || null,
    sessionStatus: room.sessionStatus || 'idle', // idle | generating | done | error
  };
}

// ---------------------------------------------------------------
// API
// ---------------------------------------------------------------

// Создать комнату (роль A)
app.post('/api/rooms', (req, res) => {
  const { name, mode } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'name_required' });

  const code = genCode();
  const room = {
    code,
    mode: mode === 'local' ? 'local' : 'online',
    A: { name: String(name).trim().slice(0, 40) },
    B: { name: '' },
    started: mode === 'local', // локальный режим стартует сразу
    currentIndex: 0,
    answers: {}, // qid -> { A: {text, skipped, level}, B: {...} }
    secretQ: { A: '', B: '' },
    sessionReport: null,
    sessionStatus: 'idle',
    updatedAt: Date.now(),
  };
  rooms.set(code, room);
  res.json({ code, role: 'A', room: publicRoom(room) });
});

// Присоединиться по коду (роль B, либо переподключение A)
app.post('/api/rooms/:code/join', (req, res) => {
  const room = rooms.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const { name } = req.body || {};
  if (!name || !String(name).trim()) return res.status(400).json({ error: 'name_required' });

  let role;
  if (!room.B.name) {
    role = 'B';
    room.B.name = String(name).trim().slice(0, 40);
  } else if (!room.A.name) {
    role = 'A';
    room.A.name = String(name).trim().slice(0, 40);
  } else {
    return res.status(409).json({ error: 'room_full' });
  }
  room.started = true;
  touch(room);
  res.json({ role, room: publicRoom(room) });
});

// Локальный режим: сразу задать оба имени и стартовать
app.post('/api/rooms/:code/start-local', (req, res) => {
  const room = rooms.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const { nameA, nameB } = req.body || {};
  room.A.name = (nameA || room.A.name || 'Игрок 1').trim().slice(0, 40);
  room.B.name = (nameB || 'Игрок 2').trim().slice(0, 40);
  room.started = true;
  touch(room);
  res.json({ room: publicRoom(room) });
});

// Получить состояние комнаты (используется для поллинга)
app.get('/api/rooms/:code', (req, res) => {
  const room = rooms.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  res.json({ room: publicRoom(room) });
});

// Отправить/обновить ответ на вопрос
app.post('/api/rooms/:code/answer', (req, res) => {
  const room = rooms.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const { role, qid, text, skipped, level } = req.body || {};
  if (!['A', 'B'].includes(role) || !qid) return res.status(400).json({ error: 'bad_request' });
  if (!room.answers[qid]) room.answers[qid] = {};
  room.answers[qid][role] = { text: text || '', skipped: !!skipped, level: level || null, ts: Date.now() };
  touch(room);
  res.json({ room: publicRoom(room) });
});

// Продвинуть текущий вопрос вперёд
app.post('/api/rooms/:code/advance', (req, res) => {
  const room = rooms.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const { currentIndex } = req.body || {};
  if (typeof currentIndex === 'number' && currentIndex > room.currentIndex) {
    room.currentIndex = currentIndex;
  }
  touch(room);
  res.json({ room: publicRoom(room) });
});

// Секретный вопрос
app.post('/api/rooms/:code/secret', (req, res) => {
  const room = rooms.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'room_not_found' });
  const { role, text } = req.body || {};
  if (!['A', 'B'].includes(role) || !text) return res.status(400).json({ error: 'bad_request' });
  room.secretQ[role] = String(text).slice(0, 500);
  touch(room);
  res.json({ room: publicRoom(room) });
});

// Сгенерировать мини-сессию психолога (Anthropic API)
app.post('/api/rooms/:code/session', async (req, res) => {
  const room = rooms.get(req.params.code);
  if (!room) return res.status(404).json({ error: 'room_not_found' });

  if (room.sessionReport) {
    return res.json({ room: publicRoom(room) });
  }
  if (room.sessionStatus === 'generating') {
    return res.json({ room: publicRoom(room) });
  }
  if (!GROQ_API_KEY) {
    return res.status(500).json({ error: 'no_api_key' });
  }

  room.sessionStatus = 'generating';

  try {
    const { questions } = req.body || {}; // клиент присылает список {qid, level, category, q}
    const nameA = room.A.name || 'Партнёр 1';
    const nameB = room.B.name || 'Партнёр 2';

    let lines = [];
    (questions || []).forEach((q) => {
      const a = room.answers[q.qid] && room.answers[q.qid].A;
      const b = room.answers[q.qid] && room.answers[q.qid].B;
      const hasA = a && !a.skipped && a.text;
      const hasB = b && !b.skipped && b.text;
      if (hasA || hasB) {
        lines.push(`Категория: ${q.category}. Вопрос: ${q.q}`);
        lines.push(`${nameA}: ${hasA ? a.text : '(пропустил(а))'}`);
        lines.push(`${nameB}: ${hasB ? b.text : '(пропустил(а))'}`);
        lines.push('');
      }
    });
    let secretsBlock = '';
    if (room.secretQ.A || room.secretQ.B) {
      secretsBlock =
        `\nСекретные вопросы друг другу:\n${nameA} спросил(а): ${room.secretQ.A || '—'}\n` +
        `${nameB} спросил(а): ${room.secretQ.B || '—'}\n`;
    }

    const prompt = `Ты — тёплый, тактичный семейный психолог. Пара по имени ${nameA} и ${nameB} только что прошли совместную игру-диалог с вопросами о привычках, романтике, границах, желаниях и фантазиях. Ниже — их ответы (могут быть пропуски).

${lines.join('\n')}${secretsBlock}

На основе этих ответов подготовь короткую поддерживающую мини-сессию для пары. Никогда не ставь диагнозы, не оценивай и не критикуй никого лично, не делай выводов о психическом здоровье. Пиши тепло, конкретно, без клише, опираясь на реальные детали из ответов, где это уместно. Отвечай СТРОГО в формате JSON, без markdown-разметки и кодовых блоков, без пояснений до или после — только один JSON-объект, по схеме:
{
  "opening": "1-2 тёплых предложения о паре в целом",
  "strengths": ["3-4 конкретные сильные стороны пары на основе ответов"],
  "growAreas": ["2-4 бережные, не осуждающие рекомендации — на что обратить внимание или что стоит добавить"],
  "tryTogether": ["2-4 конкретных практических идеи, что попробовать вместе в ближайшее время"],
  "conversationStarters": ["2-3 вопроса или темы, которые стоит обсудить вживую после игры"],
  "closing": "тёплое ободряющее завершение, 1-2 предложения"
}`;

    // Groq — бесплатный API, совместимый с форматом OpenAI Chat Completions
    const apiRes = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + GROQ_API_KEY,
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        max_tokens: 1200,
        temperature: 0.7,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!apiRes.ok) {
      const errText = await apiRes.text();
      console.error('Groq API error:', apiRes.status, errText);
      room.sessionStatus = 'error';
      return res.status(502).json({ error: 'ai_error' });
    }

    const data = await apiRes.json();
    const textOut = data.choices && data.choices[0] && data.choices[0].message
      ? data.choices[0].message.content
      : '{}';
    let parsed;
    try {
      const clean = (textOut || '{}').replace(/```json|```/g, '').trim();
      parsed = JSON.parse(clean);
    } catch (e) {
      console.error('Failed to parse AI JSON:', e);
      room.sessionStatus = 'error';
      return res.status(502).json({ error: 'ai_parse_error' });
    }

    room.sessionReport = parsed;
    room.sessionStatus = 'done';
    touch(room);
    res.json({ room: publicRoom(room) });
  } catch (e) {
    console.error(e);
    room.sessionStatus = 'error';
    res.status(500).json({ error: 'server_error' });
  }
});

// ---------------------------------------------------------------
// Статика фронтенда
// ---------------------------------------------------------------
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`«Ближе» backend запущен на порту ${PORT}`);
  if (!GROQ_API_KEY) {
    console.warn('ВНИМАНИЕ: GROQ_API_KEY не задан — мини-сессия психолога работать не будет.');
  }
});
